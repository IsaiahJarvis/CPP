//hello1.cpp
//Displays a greeting.
//Illustrates a using directive.
//Such a using directive is often used for namespace std,
//but should not be used for other namespaces.

#include <iostream>
using namespace std;

int main()
{
    cout << "\nHello, world!\n" << endl;
}
