//test.cpp
//Just some source code to be used as test input for balanced symbol checking.

#include <iostream>
#include <cmath>
using namespace std;

int main()
{
    cout << "\nGood-bye, (cruel) world!\n" << endl;
    int a[] = {1, 2, 3, 4, 5};
    for (int i=0; i<5; i++)
        cout << a[i] << " ";
    for (int i=0; i<5; i++)
        cout << sqrt((double)a[i]) << " ";
    cout << endl;
}
